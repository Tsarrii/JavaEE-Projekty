/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package bingus.cookie;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.time.Instant;

/**
 *
 * @author arinn
 */
@WebServlet("/first")
public class FirstServlet extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String cookieName = "visitTime";
        String cookieValue = Instant.now().toString();
        
        Cookie cookie = new Cookie(cookieName, cookieValue);
        cookie.setMaxAge(30);
        cookie.setPath("/");
        
        response.addCookie(cookie);
        
        response.setContentType("text/html");
        response.getWriter().println("<h1>Cookie has been set!</h1>");
        response.getWriter().println("<p>Visit <a href='second'>second</a> to check the remaining time.</p>");
    }

}
