/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package bingus.cookie;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.time.Duration;
import java.time.Instant;

/**
 *
 * @author arinn
 */
@WebServlet("/second")
public class SecondServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        String visitTime = null;
        
        if(cookies != null){
            for (Cookie cookie : cookies){
                if ("visitTime".equals(cookie.getName())) {
                    visitTime = cookie.getValue();
                    break;
                }
            }
        }
        
        response.setContentType("text/html");
    if (visitTime == null) {
        response.getWriter().println("<h1>No cookie found!</h1>");
        response.getWriter().println("<p>Please visit <a href='first'>first</a> to set the cookie.</p>");
    } else {
        Instant cookieInstant = Instant.parse(visitTime);
        Instant now = Instant.now();
        Duration duration = Duration.between(now,
        cookieInstant.plusSeconds(30));
        if (duration.isNegative()) {
            response.getWriter().println("<h1>Cookie has expired!</h1>");
            response.getWriter().println("<p>Please visit <a href='first'>first</a> to set a new cookie.</p>");
        } else {
            long secondsRemaining = duration.getSeconds();
            response.getWriter().println("<h1>Time Remaining:</h1>");
            response.getWriter().println("<p>" + secondsRemaining + " seconds left until the cookie expires.</p>");
            } 
        }
    }
}