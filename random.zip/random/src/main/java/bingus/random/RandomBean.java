/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bingus.random;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.Random;

/**
 *
 * @author arinn
 */

@Named
@SessionScoped
public class RandomBean implements Serializable{
    private int number;
    private int randomnumber;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getRandomnumber() {
        return randomnumber;
    }

    public void setRandomnumber(int randomnumber) {
        this.randomnumber = randomnumber;
    }

    public boolean isInitialized() {
        return initialized;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }
    private boolean initialized = false;
    
    
    public String submit(){
        Random rand = new Random();
        
        initialized = true;
        randomnumber = rand.nextInt(1000) + number;
        
        return "random";
    }
}
