/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bingus.display2;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author arinn
 */
@Named
@SessionScoped
public class DisplayBean implements Serializable{
    public static class Person{
        private String name;
        private String address;
        private String number;

        public Person(String name, String address, String number) {
            this.name = name;
            this.address = address;
            this.number = number;
        }

        public String getAddress() {
            return address;
        }

        public String getName() {
            return name;
        }

        public String getNumber() {
            return number;
        }
        
    }

    private static final ArrayList<Person> people
        = new ArrayList<Person>(Arrays.asList(
        new Person("Jim", "WashingtonDC", "3829"),
        new Person("Tim", "Marketing", "54879"),
        new Person("Badavin", "VaticanCity", "4732908")
        )); 
    
    private String name;
    private String address;
    private String number;
    
    public ArrayList<Person> getPeople() {
        return people;
    }

    public void addPeople(ArrayList<Person> people) {
        people.add(new Person(name, address, number));
        name = "";
        address = "";
        number = "";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
    
}
