/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bingus.oddeven;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;

/**
 *
 * @author arinn
 */
@Named
@SessionScoped
public class OddEvenBean implements Serializable{
    private int number;
    private boolean initialized = false;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public boolean isInitialized() {
        return initialized;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }
    
    public String submit(){
        initialized = true;
        if(number % 2 == 0){
            return "even";
        }
        else{
            return "odd";
        }
    }
}
