
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author arinn
 */

@Named
@SessionScoped
public class helloBean implements Serializable{
    private String firstname;
    private String secondname;
    private String greeting;
    private boolean initialized = false;

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setSecondname(String secondname) {
        this.secondname = secondname;
    }

    public void setGreeting(String greeting) {
        this.greeting = greeting;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }
    

    public String getFirstname() {
        return firstname;
    }

    public String getSecondname() {
        return secondname;
    }

    public String getGreeting() {
        return greeting;
    }

    public boolean isInitialized() {
        return initialized;
    }
    
    public String greet() {
        greeting = "Hello, " + firstname + " " + secondname + "!";
        initialized = true;
        return "display";
    }
    
}
