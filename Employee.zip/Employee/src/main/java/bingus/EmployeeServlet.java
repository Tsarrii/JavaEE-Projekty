/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package bingus;

import bingus.Employee;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author arinn
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void init() {
        // Store employees in ServletContext so they persist
        getServletContext().setAttribute("employees", new ArrayList<Employee>());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String department = request.getParameter("department");

        // Retrieve the stored employee list
        List<Employee> employees = (List<Employee>) getServletContext().getAttribute("employees");
        
        // Add new employee
        int id = employees.size() + 1;
        employees.add(new Employee(id, name, department));

        // Redirect to employees list page
        response.sendRedirect("EmployeeServlet");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Employee> employees = (List<Employee>) getServletContext().getAttribute("employees");
        request.setAttribute("employees", employees);
        request.getRequestDispatcher("employees.jsp").forward(request, response);
    }
}
